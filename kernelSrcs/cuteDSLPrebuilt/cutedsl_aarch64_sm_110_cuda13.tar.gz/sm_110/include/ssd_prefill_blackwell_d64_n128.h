
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} ssd_prefill_blackwell_d64_n128_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_ssd_prefill_blackwell_d64_n128_cuda_init(void **);
void _mlir_ssd_prefill_blackwell_d64_n128_cuda_load_to_device(void **);
static inline void ssd_prefill_blackwell_d64_n128_Kernel_Module_Load(ssd_prefill_blackwell_d64_n128_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_ssd_prefill_blackwell_d64_n128_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_ssd_prefill_blackwell_d64_n128_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void ssd_prefill_blackwell_d64_n128_Kernel_Module_Unload(ssd_prefill_blackwell_d64_n128_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_x_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} ssd_prefill_blackwell_d64_n128_Tensor_dt_in_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_blackwell_d64_n128_Tensor_A_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_B_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_C_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_blackwell_d64_n128_Tensor_D_fp32_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_blackwell_d64_n128_Tensor_dt_bias_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_output_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_state_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_dA_cumsum_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_dt_proc_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[5];
    int64_t dynamic_strides[4];
} ssd_prefill_blackwell_d64_n128_Tensor_y_ws_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} ssd_prefill_blackwell_d64_n128_Tensor_fstate_ws_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} ssd_prefill_blackwell_d64_n128_Tensor_D_fp16_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_ssd_prefill_blackwell_d64_n128__mlir_ciface_cutlass_ssd_blackwell_aot_Tensorgmemoi64i64i641_Tensorgmemoi64i641_Tensorgmemo1_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemo1_Tensorgmemo1_Tensorgmemoi64i64i641_Tensorgm(void **args, int32_t num_args);

static inline int32_t cute_dsl_ssd_prefill_blackwell_d64_n128_wrapper(ssd_prefill_blackwell_d64_n128_Kernel_Module_t *module, ssd_prefill_blackwell_d64_n128_Tensor_x_t *x, ssd_prefill_blackwell_d64_n128_Tensor_dt_in_t *dt_in, ssd_prefill_blackwell_d64_n128_Tensor_A_t *A, ssd_prefill_blackwell_d64_n128_Tensor_B_t *B, ssd_prefill_blackwell_d64_n128_Tensor_C_t *C, ssd_prefill_blackwell_d64_n128_Tensor_D_fp32_t *D_fp32, ssd_prefill_blackwell_d64_n128_Tensor_dt_bias_t *dt_bias, ssd_prefill_blackwell_d64_n128_Tensor_output_t *output, ssd_prefill_blackwell_d64_n128_Tensor_state_t *state, ssd_prefill_blackwell_d64_n128_Tensor_dA_cumsum_t *dA_cumsum, ssd_prefill_blackwell_d64_n128_Tensor_dt_proc_t *dt_proc, ssd_prefill_blackwell_d64_n128_Tensor_y_ws_t *y_ws, ssd_prefill_blackwell_d64_n128_Tensor_fstate_ws_t *fstate_ws, ssd_prefill_blackwell_d64_n128_Tensor_D_fp16_t *D_fp16, int32_t seq_len_val, int32_t nchunks_val, cudaStream_t stream) {
    int32_t ret;
    void *args[18] = {
        x, dt_in, A, B, C, D_fp32, dt_bias, output, state, dA_cumsum, dt_proc, y_ws, fstate_ws, D_fp16, &seq_len_val, &nchunks_val, &stream,
        &ret
    };
    _mlir_ssd_prefill_blackwell_d64_n128__mlir_ciface_cutlass_ssd_blackwell_aot_Tensorgmemoi64i64i641_Tensorgmemoi64i641_Tensorgmemo1_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemo1_Tensorgmemo1_Tensorgmemoi64i64i641_Tensorgm(args, 18);
    return ret;
}
